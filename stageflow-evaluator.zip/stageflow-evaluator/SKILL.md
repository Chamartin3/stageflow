---
name: stageflow-evaluator
description: This skill should be used when the user needs to evaluate elements against StageFlow processes to understand workflow progression. Use this skill when: (1) evaluating JSON elements against process definitions, (2) diagnosing why an element is stuck at a stage, (3) understanding what data changes are needed to progress, (4) interpreting lock validation failures. The skill NEVER modifies processes - it only evaluates elements and explains how to progress.
---

# StageFlow Evaluator

## Overview

StageFlow is a data-centric workflow management tool for evaluating elements (JSON objects) against process definitions. This skill provides guidance for:

1. Loading and viewing process definitions
2. Evaluating elements against processes
3. Interpreting evaluation results (incomplete/blocked/ready)
4. Understanding what data changes are needed to progress

**Core Principle**: StageFlow is read-only - it never mutates data. To progress through a workflow, the application must modify the element data to satisfy gate locks.

## Workflow

### Step 1: Identify Process Location

The process can be loaded from:
- **File path**: `process.yaml` or `/path/to/process.yaml`
- **Registry reference**: `@process_name` (stored in `~/.stageflow/`)

To list registry processes:
```bash
uv run stageflow process registry list
```

### Step 2: View Process Structure

Before evaluation, understand the process structure:

```bash
uv run stageflow process view <process_source>
```

This shows:
- All stages and their descriptions
- Expected properties (fields) for each stage
- Gate transitions between stages
- Process validity status

### Step 3: Evaluate Element

Run evaluation with the element JSON:

```bash
# From file
uv run stageflow evaluate <process_source> -e element.json

# From stdin
echo '{"email": "user@example.com"}' | uv run stageflow evaluate <process_source>

# With explicit stage override
uv run stageflow evaluate <process_source> -e element.json --stage checkout

# With JSON output for parsing
uv run stageflow evaluate <process_source> -e element.json --json

# With schema hints
uv run stageflow evaluate <process_source> -e element.json --show-schema
```

### Step 4: Interpret Results

Evaluation returns one of three statuses:

| Status | Meaning | Action Required |
|--------|---------|-----------------|
| `incomplete` | Missing required properties for current stage | Add missing fields to element |
| `blocked` | Has required properties but fails gate locks | Fix lock validation errors |
| `ready` | All locks pass, can transition to next stage | Application can update stage |

### Step 5: Provide Resolution Guidance

Based on evaluation results, explain to the user:

1. **Current Status**: What stage the element is at and its status
2. **What's Missing**: Specific properties or values needed
3. **Lock Failures**: Which locks failed and why (with custom error messages)
4. **Next Steps**: What data changes would allow progression
5. **Expected Actions**: If the process defines `expected_actions`, provide those instructions

## Understanding Lock Types

When evaluation fails, identify which lock type failed and explain resolution:

| Lock Type | What It Checks | Resolution |
|-----------|----------------|------------|
| `exists` | Property must exist | Add the missing property |
| `equals` | Exact value match | Set property to expected value |
| `not_empty` | String/list/dict not empty | Provide non-empty value |
| `type_check` | Correct data type | Convert to expected type (int, str, bool, etc.) |
| `greater_than` | Numeric > value | Increase value above threshold |
| `less_than` | Numeric < value | Decrease value below threshold |
| `range` | Value within [min, max] | Adjust value to be within range |
| `regex` | Pattern match | Format value to match pattern |
| `contains` | Contains substring/element | Include required content |
| `length` | Exact length | Adjust to exact length |
| `in_list` | Value in allowed list | Use one of the allowed values |
| `not_in_list` | Value not in blocked list | Use a different value |
| `conditional` | If-then-else logic | Satisfy the appropriate branch |
| `or_logic` | At least one path passes | Satisfy any one of the paths |

## Example Evaluation Workflow

Given an element that returns `incomplete`:

```
Status: incomplete
Validation Messages:
  - Missing required property 'title' (suggested default: None)
  - Missing required property 'content' (suggested default: None)
```

Explain to user:
1. The element is missing `title` and `content` properties
2. To progress, add these properties:
   ```json
   {
     "title": "My Document",
     "content": "Document body text..."
   }
   ```
3. Re-run evaluation to check if ready

Given an element that returns `blocked`:

```
Status: blocked
Gate Results:
  submit_for_review: BLOCKED
    - Lock 'exists' failed: Document title is required
```

Explain to user:
1. All required stage fields exist, but gate validation failed
2. The `exists` lock for title failed - the property exists but may be null
3. Ensure `title` has an actual value, not null/undefined

## CLI Commands Reference

| Command | Purpose |
|---------|---------|
| `stageflow process view <source>` | View process structure |
| `stageflow evaluate <source> -e <element>` | Evaluate element |
| `stageflow evaluate <source> --json` | Get JSON output |
| `stageflow evaluate <source> --show-schema` | Show expected schema |
| `stageflow evaluate <source> --stage <id>` | Override current stage |
| `stageflow process registry list` | List registry processes |
| `stageflow process diagram <source> -o <file>` | Generate diagram |

## Important Constraints

1. **Never modify processes** - This skill only evaluates elements and explains how to progress
2. **Element changes are external** - StageFlow doesn't change data; the application must
3. **Deterministic** - Same element + same process = same results
4. **Stage order matters** - Check if evaluation accounts for `stage_prop` auto-extraction

## Resources

### references/

- `stageflow_reference.md` - Detailed lock type specifications and CLI options

Refer to the reference file when more detail is needed on specific lock configurations or advanced CLI options.
