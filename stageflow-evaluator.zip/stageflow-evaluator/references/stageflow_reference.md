# StageFlow Reference

## Process Definition Schema

A StageFlow process is defined in YAML/JSON:

```yaml
process:
  name: string                    # Required: Process identifier
  description: string             # Required: Human-readable description
  initial_stage: string           # Required: Starting stage ID
  final_stage: string             # Required: Terminal stage ID
  stage_prop: string              # Optional: Property path for auto-extracting stage from element
  regression_policy: string       # Optional: "ignore", "warn" (default), or "block"

  stages:
    stage_id:
      name: string                # Display name
      description: string         # Optional: Human-readable context
      fields:                     # Expected properties (3 syntax levels)
        - property_name           # Level 1: Simple list
        # OR
        property: type            # Level 2: Type shortcuts
        # OR
        property:                 # Level 3: Full specs
          type: string
          format: email

      expected_actions:           # Optional: User guidance
        - name: string
          description: string
          instructions: [string]
          related_properties: [string]

      gates:
        gate_name:
          target_stage: string
          locks: [Lock]           # Validation rules (AND logic)
```

## Lock Type Specifications

### EXISTS
Property must exist (not undefined).

```yaml
# Shorthand
- exists: "property.path"

# Full form
- type: exists
  property_path: "property.path"
  error_message: "Custom error"
```

### EQUALS
Exact value match.

```yaml
- type: equals
  property_path: "status"
  expected_value: "active"
  error_message: "Status must be active"
```

### NOT_EMPTY
Value must not be empty (for strings, lists, dicts).

```yaml
- type: not_empty
  property_path: "name"
  error_message: "Name cannot be empty"
```

### TYPE_CHECK
Validate data type.

```yaml
- type: type_check
  property_path: "age"
  expected_value: "int"  # Options: int, str, bool, list, dict, float
```

### GREATER_THAN
Numeric comparison (value > threshold).

```yaml
- type: greater_than
  property_path: "age"
  expected_value: 18
  error_message: "Must be over 18"
```

### LESS_THAN
Numeric comparison (value < threshold).

```yaml
- type: less_than
  property_path: "quantity"
  expected_value: 100
```

### RANGE
Value within range [min, max] inclusive.

```yaml
- type: range
  property_path: "score"
  expected_value: [0, 100]
  error_message: "Score must be between 0 and 100"
```

### REGEX
Pattern matching.

```yaml
- type: regex
  property_path: "email"
  expected_value: "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$"
  error_message: "Invalid email format"
```

### CONTAINS
Check if value contains substring/element.

```yaml
- type: contains
  property_path: "features"
  expected_value: "premium"
```

### LENGTH
Exact length validation.

```yaml
- type: length
  property_path: "phone"
  expected_value: 10
  error_message: "Phone must be exactly 10 digits"
```

### IN_LIST
Value must be in allowed list.

```yaml
- type: in_list
  property_path: "role"
  expected_value: ["admin", "user", "moderator"]
  error_message: "Invalid role"
```

### NOT_IN_LIST
Value must not be in blocked list.

```yaml
- type: not_in_list
  property_path: "status"
  expected_value: ["banned", "suspended"]
```

### CONDITIONAL
If-then-else logic.

```yaml
- type: conditional
  if:
    - type: equals
      property_path: "user_type"
      expected_value: "premium"
  then:
    - type: greater_than
      property_path: "credits"
      expected_value: 100
  else:
    - type: greater_than
      property_path: "credits"
      expected_value: 10
```

### OR_LOGIC / OR_GROUP
At least one path must pass.

```yaml
- type: or_logic
  paths:
    - locks:
        - type: equals
          property_path: "verified_email"
          expected_value: true
    - locks:
        - type: equals
          property_path: "verified_phone"
          expected_value: true
```

## CLI Command Details

### stageflow evaluate

```bash
stageflow evaluate <source> [OPTIONS]
```

**Arguments:**
- `source`: Process file path or `@registry_name`

**Options:**
- `-e, --element PATH`: Element file (JSON/YAML). If omitted, reads from stdin
- `-s, --stage ID`: Override current stage
- `--json`: Output in JSON format
- `--show-schema`: Display expected schema
- `--cumulative-schema`: Show all properties from previous stages
- `-v, --verbose`: Verbose output

**Stage Selection Precedence:**
1. `--stage` flag (highest)
2. Auto-extraction from element via `stage_prop`
3. Process `initial_stage` (lowest)

### stageflow process view

```bash
stageflow process view <source>
```

Shows:
- Process validity status
- Initial and final stages
- All stages with descriptions
- Expected properties per stage
- Gate transitions

### stageflow process registry

```bash
# List all processes
stageflow process registry list [--json]

# Import process
stageflow process registry import <file> --name <name>

# Export process
stageflow process registry export <name> <output_file>

# Delete process
stageflow process registry delete <name> [--force]
```

### stageflow process diagram

```bash
stageflow process diagram <source> -o <output.md>
```

Generates a Mermaid diagram of the process flow.

### stageflow process schema

```bash
stageflow process schema <source> <stage_id>
```

Generates JSON Schema for a specific stage.

## JSON Output Structure

When using `--json` flag, evaluation returns:

```json
{
  "process": {
    "name": "string",
    "description": "string",
    "initial_stage": "string",
    "final_stage": "string",
    "stages": [...],
    "valid": true,
    "consistency_issues": []
  },
  "evaluation": {
    "stage": "string",
    "status": "incomplete|blocked|ready",
    "regression": false,
    "actions": [
      {"description": "string", "type": "execute"}
    ],
    "gate_results": {},
    "regression_details": {
      "detected": false,
      "policy": "warn",
      "failed_stages": [],
      "failed_statuses": {}
    },
    "configured_actions": [...],
    "validation_messages": [...]
  }
}
```

## Evaluation Status Meanings

| Status | Description | Gate Behavior |
|--------|-------------|---------------|
| `incomplete` | Missing required properties for current stage fields | Gates not evaluated |
| `blocked` | Has fields but no gate locks pass | All gates blocked |
| `ready` | At least one gate's locks all pass | Ready to transition |

## Regression Detection

StageFlow tracks backward progression:

- **ignore**: No regression checks
- **warn** (default): Detects regression, reports in results
- **block**: Treats regression as validation failure

Regression detected when element would pass a previous stage's gates.

## Expected Actions

Processes can define `expected_actions` to guide users:

```yaml
expected_actions:
  - name: "action_id"
    description: "What the user should do"
    instructions:
      - "Step 1"
      - "Step 2"
    related_properties:
      - "property.to.modify"
```

These appear in evaluation output to help users understand how to progress.
